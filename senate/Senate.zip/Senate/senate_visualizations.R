# Read population and senate makeup data and visualize the percentage
# of the US population represented by each party in the senate.

if (!require(tidyverse))
install.packages("tidyverse")
library(tidyverse)

if (!require(ggplot2))
install.packages("tidyverse")
library(ggplot2)

# Read in apportionment population
pop_2020 <- read_excel("apportionment-2020-table01.xlsx", skip = 3)

# Read in senators
senators <- read_excel("senators.xlsx")

# Reduce population to just state and population
names(pop_2020) <- c("State", "Population", "x", "y")
pop_2020 <- pop_2020 %>% select(c("State", "Population"))

# Reduce senators to just name, state, party
senators <- senators[, 1:3]
names(senators) <- c("Name", "State", "Party")

# Merge senators and pop_2020
senate_pop <- merge(senators, pop_2020)

# Group by party and total the population
# Halve the population
senate_pop <- senate_pop %>% mutate(Population = Population / 2)
# Create the summary dataframe
total_pop <- sum(senate_pop$Population)
party_summary <- senate_pop %>% group_by(Party) %>% summarize(Percent=sum(Population) / total_pop)
# plot
party_colors = c("#2222CC", "#22cc22", "#cc2222")
ggplot(party_summary) + geom_col(aes(x=Party, y=Percent, fill = Party)) + 
  scale_fill_manual(values = party_colors)

# Create a visualization of senators by party
senate_pop <- senate_pop[order(senate_pop$Population),]
senate_pop$Name <- factor(senate_pop$Name, levels = senate_pop$Name)
senate_pop <- senate_pop %>% mutate(Percent = Population / total_pop * 100)
# If you're playing with the code and can place the state names in a way
# that looks better, I'd love to see your solution!  I don't have time to mess with
# it but would prefer it looks better!
ggplot(senate_pop) + geom_col(aes(x=Name, y=Percent, fill = Party)) + 
  scale_fill_manual(values = party_colors) + theme(axis.text.x=element_blank()) +
  geom_text(x = senate_pop$Name, y = senate_pop$Percent + .2,label = senate_pop$State, angle = 90, size = 2)

# TO DO:
# Include a bar for percentage of the population without senate representation
